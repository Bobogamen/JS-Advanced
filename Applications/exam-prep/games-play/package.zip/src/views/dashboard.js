import { getAllOffers } from '../api/data.js';
import { html } from '../lib.js';

const dashboardTemplate = (offers) => html`
<section id="catalog-page">
      <h1>All Games</h1>
            ${offers.length == 0 ? html`<h3 class="no-articles">No articles yet</h3>` : offers.map(gameCard) }
</section>`

const gameCard = (game) => html`
<div class="allGames">
      <div class="allGames-info">
      <img src="${game.imageUrl}">
      <h6>${game.category}</h6>
      <h2>${game.title}</h2>
      <a href="/offer/${game._id}" class="details-button">Details</a>
      </div>
</div>`

export async function dashboardView(ctx) {
      const offers = await getAllOffers()

      ctx.render(dashboardTemplate(offers));
}

